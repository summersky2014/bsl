/// <reference path="../node_modules/bsl/typings/module.d.ts" />
/// <reference path="./module.d.ts" />

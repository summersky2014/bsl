import { css, StyleSheet } from 'bsl/css-in-js';
// import { rem } from 'bsl/styles/mixins';

export const component = StyleSheet.create({
  root: css({
    
  })
});
import { StyleSheet } from 'aphrodite/no-important';
// import { rem } from 'bsl/styles/mixins';

export const component = StyleSheet.create({
  root: {
    
  }
});
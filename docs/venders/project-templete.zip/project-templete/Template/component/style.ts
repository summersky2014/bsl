import { create, css } from 'bsl/styles/css-in-js';
// import { rem } from 'bsl/styles/mixins';

export const component = create({
  root: css({
    
  })
});
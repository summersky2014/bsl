import BSL from 'bsl/typings';
import * as React from 'react';
import { css } from 'aphrodite/no-important';
import * as styles from './style';

interface Props extends BSL.ComponentProps {
}

function Component(props: Props) {
  return (
    <div className={css(styles.root)}></div>
  );
}

export default Component;

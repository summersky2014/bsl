import BSL from 'bsl/typings';
import * as React from 'react';
import * as styles from './style';

interface Props extends BSL.ComponentProps {
}

function Component(props: Props) {
  return (
    <div className={styles.component.root}></div>
  );
}

export default Component;

import * as React from 'react';
import { css } from 'aphrodite/no-important';
import classNames from 'classnames';
import * as styles from './style';
import { Match, pathParams } from './export';
import PageComponent, { PageProps } from 'bsl/app/PageComponent';
// import RequestView, { CompleteState, EmptyState, FailState, LoadingState, TimeoutState } from 'bsl/components/RequestView';
// import { LoadingView, EmptyView, FailView, TimeoutView } from 'bsl/components/StateView';

import View from './View';

interface Props extends PageProps<Match> {
}

interface State {
}

class Page extends PageComponent<Props, State> {
  constructor(props: Props, state: State) {
    super(props, state);
    this.init();
  }

  public pageRender(): JSX.Element {
    return (
      // <RequestView
      //   className={css(styles.page.root)}
      //   api=""
      // >
      //   {(data) => (
      //     <React.Fragment>
      //       <CompleteState>
      //         {() => (
      //           <View />
      //         )}
      //       </CompleteState>
      //       <LoadingState>
      //         <LoadingView />
      //       </LoadingState>
      //       <EmptyState>
      //         <EmptyView />
      //       </EmptyState>
      //       <FailState>
      //         <FailView />
      //       </FailState>
      //       <TimeoutState>
      //         <TimeoutView />
      //       </TimeoutState>
      //     </React.Fragment>
      //   )}
      // </RequestView>
      <div className={classNames(css(styles.page.root), 'iosViewport')}>
        <View />
      </div>
    );
  }
}

export { pathParams };
export default Page;
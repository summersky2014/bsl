import PageComponent, { PageProps } from 'bsl/app/PageComponent';
import classNames from 'classnames';
import * as React from 'react';
import { linkParams, Match, pathParams } from './export';
import * as styles from './style';
import View from './View';
// import RequestView, { CompleteState, EmptyState, FailState, LoadingState, TimeoutState } from 'bsl/components/RequestView';
// import { LoadingView, EmptyView, FailView, TimeoutView } from 'bsl/components/StateView';

interface Props extends PageProps<Match> {
}

interface State {
}

class Page extends PageComponent<Props, State> {
  constructor(props: Props, state: State) {
    super(props, state);
    this.init();
  }

  public pageRender(): JSX.Element {
    return (
      // <RequestView
      //   className={classNames(styles.page.root, 'iosViewport')}
      //   api=""
      // >
      //   {(data) => (
      //     <React.Fragment>
      //       <CompleteState>
      //         {() => (
      //           <View />
      //         )}
      //       </CompleteState>
      //       <LoadingState>
      //         <LoadingView />
      //       </LoadingState>
      //       <EmptyState>
      //         <EmptyView />
      //       </EmptyState>
      //       <FailState>
      //         <FailView />
      //       </FailState>
      //       <TimeoutState>
      //         <TimeoutView />
      //       </TimeoutState>
      //     </React.Fragment>
      //   )}
      // </RequestView>
      <div className={classNames(styles.page.root, 'iosViewport')}>
        <View />
      </div>
    );
  }
}

export { pathParams, linkParams };
export default Page;
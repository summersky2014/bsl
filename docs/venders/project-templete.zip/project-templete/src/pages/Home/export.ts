/** 这个根据情况改，一般不用改 */
/** 格式：_序号_名称
 * true: 必选
 * false: 可选
 */
const match = {
  '_1_example': true
};

/** 这个可以不用改 */
export type Match = Record<keyof typeof match, string>;
/** 路由参数名称及顺序，这个可以不用改 */
export const pathParams = Object.keys(match).map((key) => `${key}${match[key as keyof typeof match] ? '' : '?'}`);

/** 这个根据情况改，一般不用改 */
export function linkParams(params: Match) {
  const keys = Object.keys(match) as (keyof Partial<Match>)[];
  const routeParams = [];
  for (let i = 0; i < keys.length; i++) {
    if (params[keys[i]]) {
      routeParams.push(encodeURIComponent(params[keys[i]]!));
    }
  }
  return routeParams;
}
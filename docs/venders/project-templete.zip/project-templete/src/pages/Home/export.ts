import create, { M } from 'bsl/utils/router/type';
/** 格式：_序号_名称
 * true: 必选
 * false: 可选
 */
const match = {
  _1_example: true
} as const;

const { linkParams, pathParams } = create(match);

export type Match = M<typeof match>;
export {
  linkParams, pathParams
};
import { css, StyleSheet } from 'bsl/css-in-js';
// import { rem } from 'bsl/styles/mixins';

export const page = StyleSheet.create({
  root: css({
    minHeight: '100vh',
    position: 'relative'
  })
});
import { create, css } from 'bsl/styles/css-in-js';
// import { rem } from 'bsl/styles/mixins';

export const page = create({
  root: css({
    minHeight: '100vh',
    position: 'relative'
  })
});
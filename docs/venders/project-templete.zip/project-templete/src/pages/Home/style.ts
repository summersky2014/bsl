import { StyleSheet, CSSProperties } from 'aphrodite/no-important';
// import { rem } from 'bsl/styles/mixins';

export const page = StyleSheet.create({
  root: {
    minHeight: '100vh',
    position: 'relative'
  } as CSSProperties
});
import * as React from 'react';
// import * as styles from './style';

interface Props {

}

function View(props: Props) {
  return (
    <React.Fragment>
    </React.Fragment>
  );
}

export default View;
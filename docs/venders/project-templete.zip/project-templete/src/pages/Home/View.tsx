import * as React from 'react';
// import { css } from 'aphrodite/no-important';
// import * as styles from './style';

function View() {
  return (
    <React.Fragment>
    </React.Fragment>
  );
}

export default View;
export interface Match {

}

/** 路由参数名称及顺序 */
export const pathParams: (keyof Match)[] = [];
import { StyleSheet } from 'aphrodite/no-important';
// import { rem } from 'bsl/styles/mixins';

const styles = StyleSheet.create({
  page: {
    minHeight: '100vh',
    position: 'relative'
  }
});

export default styles;
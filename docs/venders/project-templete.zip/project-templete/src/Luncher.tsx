/// <reference path="../typings/index.d.ts" />

import 'bsl/utils/polyfill';
import 'bsl/styles/bsl.scss';
import 'bsl/styles/normalize.scss';
import './app/theme/index.scss';
import './app/config';
import * as React from 'react';
import * as ReactDOM from 'react-dom';
import { HashRouter } from 'react-router-dom';
import AppStack from 'bsl/app/PageStack';
import { Subscription, Context } from 'bsl/app/Scheduler';
import routes from './app/routes';

const App = () => {
  return (
    <Subscription source={{}}>
      {(value: object) => (
        <Context.Provider value={value}>
          <HashRouter>
            <AppStack>
              {routes}
            </AppStack>
          </HashRouter>
        </Context.Provider>
      )}
    </Subscription>
  );
};

ReactDOM.render(
  <App />,
  document.getElementById('reactRoot')
);

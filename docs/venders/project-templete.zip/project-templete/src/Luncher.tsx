import AppStack from 'bsl/app/PageStack';
import { Context, Subscription } from 'bsl/app/Scheduler';
import 'bsl/styles/bsl.scss';
import 'bsl/styles/normalize.scss';
import 'bsl/utils/polyfill';
import historyReplace from 'bsl/utils/router/historyReplace';
import * as React from 'react';
import * as ReactDOM from 'react-dom';
import { HashRouter } from 'react-router-dom';
import './app/config';
import routes from './app/routes';
import './app/theme/index.scss';
/// <reference path="../typings/index.d.ts" />


historyReplace();

const App = () => {
  return (
    <Subscription source={{}}>
      {(value: Record<string, unknown>) => (
        <Context.Provider value={value}>
          <HashRouter>
            <AppStack>
              {routes}
            </AppStack>
          </HashRouter>
        </Context.Provider>
      )}
    </Subscription>
  );
};

ReactDOM.render(
  <App />,
  document.getElementById('reactRoot')
);

import variable from 'bsl/utils/variable';
import axios from 'axios';
import BSL from 'bsl/typings';
import isEmpty from 'bsl/utils/isEmpty';

export interface ResponseData {
  result: any;
  retCode: string;
  retMsg: string;
}

axios.defaults.transformResponse = (data: string) => {
  const { result, retCode, retMsg } = JSON.parse(data) as ResponseData;
  const response: BSL.RequestResponse<any> = {
    data: result,
    code: 200,
    msg: retMsg
  };
  
  if (retCode === '0000') {
    if (isEmpty(result)) {
      response.code = 404;
    }
  } else {
    response.code = 500;
  }

  return response;
};

switch (variable.env) {
  // 生产环境的配置
  case 'production':
    axios.defaults.baseURL = 'http://appsenior.yuejiayun.com/';
    break;
  // 预发布环境的配置
  case 'prerelease':
    axios.defaults.baseURL = 'http://appadviser.hejuzg.cn/senior/';
    break;
  // 开发环境的配置
  default:
    axios.defaults.baseURL = 'http://appadviser.hejuzg.cn/senior/';
    break;
}

import initRoutes from 'bsl/utils/router/initRoutes';
import Home from '../pages/Home';

export const routes = {
  首页: {
    base: '/',
    component: Home
  }
};

export default initRoutes(routes);
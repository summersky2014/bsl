import initRoutes from 'bsl/utils/initRoutes';
import Home from '../pages/Home';

export const routes = {
  首页: {
    base: '/',
    component: Home
  }
};

export default initRoutes(routes);
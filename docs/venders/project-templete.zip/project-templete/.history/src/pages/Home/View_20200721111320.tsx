import * as React from 'react';
// import * as styles from './style';

function View() {
  return (
    <React.Fragment>
    </React.Fragment>
  );
}

export default View;
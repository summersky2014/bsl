import * as React from 'react';
import { css } from 'aphrodite/no-important';
import styles from './style';
import PageComponent, { PageProps } from 'bsl/app/PageComponent';

interface Props extends PageProps<Match> {
}

interface State {
}

interface Match {
}

class Page extends PageComponent<Props, State> {
  constructor(props: Props, state: State) {
    super(props, state);
    this.init();
  }

  public pageRender(): JSX.Element {
    return (
      <div className={css(styles.page)}>
        
      </div>
    );
  }
}

export default Page;
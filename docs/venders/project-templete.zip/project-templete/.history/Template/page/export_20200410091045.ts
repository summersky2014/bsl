/** 格式：_序号_名称: 类型(不重要) */
const match = {
  _1_example: 'String'
};
/** 这个可以不用改 */
export type Match = typeof match;
/** 路由参数名称及顺序，这个可以不用改 */
export const pathParams = Object.keys(match).map((item) => item);
/** 这个根据情况改，一般不用改 */
export function linkParams(params: Match) {
  const keys = Object.keys(match) as (keyof Match)[];
  return keys.map((item) => encodeURIComponent(params[item]));
}
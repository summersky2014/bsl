import { StyleSheet } from 'aphrodite/no-important';
// import { rem } from 'bsl/styles/mixins';

export const page = StyleSheet.create<any>({
  root: {
    minHeight: '100vh',
    position: 'relative'
  }
});
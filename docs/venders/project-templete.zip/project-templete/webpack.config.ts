/// <reference path="./node_modules/bsl/typings/webpackConfig.d.ts" />

const task = require('bsl/task').default;
// const CopyPlugin = require('copy-webpack-plugin');
const nodePath = require('path');
const outputDir = './build';
let publicPath;

switch (process.env.NODE_ENV) {
  case 'development':
    publicPath = '/build/';
    break;
  default:
    publicPath = '';
    break;
}

webpackConfig = {
  entry: {
    index: './src/Luncher.tsx'
  },
  dirname: __dirname,
  outputDir,
  publicPath
};

module.exports = task(webpackConfig);
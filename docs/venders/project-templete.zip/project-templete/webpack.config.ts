/// <reference path="./node_modules/bsl/typings/webpackConfig.d.ts" />

const task = require('bsl/task').default;
// const CopyPlugin = require('copy-webpack-plugin');
const nodePath = require('path');

const outputDir = './build';
webpackConfig = {
  entry: {
    index: './src/Luncher.tsx'
  },
  dirname: __dirname,
  outputDir,
  publicPath: process.env.NODE_ENV === 'development' ? '/build/' : process.env.NODE_ENV === 'prerelease' ? '/build/' : '/build/'
};

module.exports = task(webpackConfig);
import { StyleSheet } from 'aphrodite/no-important';
// import { rem } from 'bsl/styles/mixins';

const styles = StyleSheet.create({
  root: {
    
  }
});

export default styles;